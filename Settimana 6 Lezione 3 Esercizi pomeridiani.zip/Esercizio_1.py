import pandas as pd
file_path="./wine.csv"
data=pd.read_csv(file_path,sep=",",header=0)
print(data.describe())
print(data.iloc[:].count())
print(data.iloc[:].mean(numeric_only=True))
print(data.iloc[:].mode())
print(data.iloc[:].median(numeric_only=True))
print(data.iloc[:].quantile(0.25,numeric_only=True))
print(data.iloc[:].quantile(0.75,numeric_only=True))
print(data.iloc[:].max(numeric_only=True))
print(data.iloc[:].min(numeric_only=True))