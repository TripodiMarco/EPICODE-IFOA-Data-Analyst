import pandas as pd
file_path="./bezdekIris.data"
data=pd.read_csv(file_path,
             names=["sepal length in cm",
                      "sepal width in cm",
                      "petal length in cm",
                      "petal width in cm",
                      "class"])
print(data.head(5))
print(data.tail(10))
print(data.describe())