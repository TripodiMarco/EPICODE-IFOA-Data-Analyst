import pandas as pd
import matplotlib.pyplot as plt

file_url="https://raw.githubusercontent.com/plotly/datasets/master/election.csv"
data=pd.read_csv(file_url,sep=",")

# Con un grafico a barre confrontiamo i voti totali presi dai tre candidati (come somma di tutti i distretti)
votes=data.iloc[:,1:4].sum()
candidates=["Coderre","Bergeron","Joly"]
plt.title("N° voti per ogni candidato")
plt.bar(candidates,votes)
plt.xlabel("Candidati")
plt.ylabel("N° di voti")
plt.show()

# Con un grafico a barre confrontiamo il numero di votanti per ogni distretto
district=data.iloc[:,7]
districts_votes=data.iloc[:,4]
plt.title("N° di voti per ogni distretto")
plt.barh(district,districts_votes)
plt.xlabel("N° di voti")
plt.ylabel("N° distretto")
plt.show()

# Visualizzare un grafico a barre comparativo dove si confrontano i voti presi nei primi 4 distretti per ogni candidato
primi_4_distretti=data.sort_values("district_id").iloc[:4,1:4]
df=pd.DataFrame(primi_4_distretti,columns=candidates)
df.plot(kind="bar")
plt.show()
plt.savefig("Immagine1_S5_L4.png",dpi=300)

# Visualizzarlo sia in formato appaiato che impilato (stacked) e salvare entrambi i grafici su disco in alta risoluzione
df.plot(kind="bar",stacked=True)
plt.show()
plt.savefig("Immagine2_S5_L4.png",dpi=300)