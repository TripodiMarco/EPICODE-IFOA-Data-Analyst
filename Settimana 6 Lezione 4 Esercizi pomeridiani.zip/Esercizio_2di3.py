# Estraiamo le prime 20 istanze della colonna AAPL delle azioni di Apple
import matplotlib.pyplot as plt
import pandas as pd

file="https://raw.githubusercontent.com/plotly/datasets/master/stockdata.csv"
data=pd.read_csv(file,sep=",")
apple=data.loc[:20,"AAPL"]
date=data.loc[:20,"Date"]
# visualizziamo il grafico tramite pyplot in modo che
#l'asse delle ascisse si chiami "Data",
plt.xlabel("Data")
# l'asse delle ordinate si chiami "Valore",
plt.ylabel("Valore")
# il titolo del grafico sia "Azioni Apple" e...
plt.title("Azioni Apple")

# ...in modo che il grafico sia rosso, la linea sia tratteggiata, vi sia un pallino come marker, 
# il markerfacecolor sia nero, la linea abbia spessore uguale a 2
plt.plot(date,apple,color="r",linewidth=2,linestyle="--",marker="o",markerfacecolor="k")
# dalle date selezionate, prendiamo solo alcune di queste, in modo che sul grafico non si sovrascrivino
plt.xticks(date[::5])
plt.show()