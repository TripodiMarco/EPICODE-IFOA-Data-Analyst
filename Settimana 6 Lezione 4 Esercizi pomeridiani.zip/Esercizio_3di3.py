import matplotlib.pyplot as plt
import pandas as pd

file="https://raw.githubusercontent.com/plotly/datasets/master/stockdata.csv"
data=pd.read_csv(file,sep=",")
date=data.loc[:,"Date"]
MSFT=data.loc[:,"MSFT"]
IBM=data.loc[:,"IBM"]
SBUX=data.loc[:,"SBUX"]
AAPL=data.loc[:,"AAPL"]
GSPC=data.loc[:,"GSPC"]
plt.subplot(1,1,1)
plt.title("Andamento azioni 2007-2016")
plt.plot(date,MSFT,color="black")
plt.plot(date,IBM,color="blue")
plt.plot(date,SBUX,color="cyan")
plt.plot(date,AAPL,color="red")
plt.plot(date,GSPC,color="orange")
plt.xticks(date[::450])
plt.xlabel("Data")
plt.ylabel("Valore")
plt.legend(["DMSFT","IBM","SBUX","AAPL","GSPC"],loc="lower right")
plt.show()
