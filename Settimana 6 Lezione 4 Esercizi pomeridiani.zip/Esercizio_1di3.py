# Estraiamo i dati della colonna MSFT relative all'andamento delle azioni di Microsoft, e visualizziamolo mediante pyplot
import matplotlib.pyplot as plt
import pandas as pd

file="https://raw.githubusercontent.com/plotly/datasets/master/stockdata.csv"
data=pd.read_csv(file,sep=",")
MSFT=data.loc[:,"MSFT"]

plt.title("Andamento azioni Microsoft 2007-2016")
plt.plot(MSFT,color="green")
plt.show()

# Estraiamo le prime 5 righe della colonna MSFT e della colonna date,
# e usiamoli come ascisse e ordinate su un grafico mediante pyplot
y=MSFT.head()
date=data.loc[:,"Date"]
x=date.head()

plt.title("Andamento azioni Microsoft primi 5 gg del 2007")
plt.plot(x,y)
plt.show()

# Facciamo lo stesso per le ultime 5 righe del dataset
y=MSFT.tail()
date=data.loc[:,"Date"]
x=date.tail()

plt.title("Andamento azioni Microsoft ultimi gg 2016")
plt.plot(x,y)
plt.show()