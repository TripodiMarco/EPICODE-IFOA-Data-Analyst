import seaborn as sns
from matplotlib import pyplot as plt
import pandas as pd

titanic=sns.load_dataset("titanic")

# Visualizzare un grafico con il numero di passeggeri di ogni classe di imbarco
df=titanic.groupby("class")["class"].count()
print(df)
df.plot(kind="bar")
plt.show()

# Fare la stessa cosa per la colonna alive
df=titanic.groupby("alive")["alive"].count()
print(df)
df.plot(kind="bar")
plt.show()

# Qual era la distribuzione delle tariffe (fare)?
sns.scatterplot(titanic["fare"])
plt.show()

# Riusciamo a vedere la distribuzione delle età dei passeggeri rispetto alla classe di imbarco? Proviamo con un boxplot e con uno swarmplot
sns.boxplot(titanic,x="class",y="age")
plt.show()
sns.swarmplot(titanic,x="class",y="age")
plt.show()

# Visualizziamo un boxplot e un lmplot rispetto alle colonne fare e survived; che cose ne deduciamo?
sns.boxplot(titanic,x="survived",y="fare")
plt.show()
sns.lmplot(titanic,x="survived",y="fare")
plt.show()