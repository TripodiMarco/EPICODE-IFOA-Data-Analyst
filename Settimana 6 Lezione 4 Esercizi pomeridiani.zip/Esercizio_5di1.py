# Da seaborn importiamo il dataset titanic, mediante:
import seaborn as sns
from matplotlib import pyplot as plt

titanic=sns.load_dataset("titanic")

# Quanti ponti c'erano sulla nave?
sns.countplot(data=titanic,x="deck")
plt.show()                                      

# Ci sono dati mancanti? Dove? Quanti? Che logica potremmo usare per gestirli?
deck=titanic.iloc[:,11].unique()
print(deck)

# Tramite seaborn visualizziamo un lmplot sulle colonne age e fare; che cosa stiamo guardando?
sns.lmplot(data=titanic, x="age", y="fare")
plt.show()