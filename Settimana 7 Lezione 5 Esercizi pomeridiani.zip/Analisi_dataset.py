import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


path="./dataset_climatico.csv"
dataset=pd.read_csv(path,sep=",")
print(dataset.head())
dataset["data_osservazione"]=pd.to_datetime(dataset["data_osservazione"])

# Pulizia dei dati, cioè rimozione dei dati mancanti
dataset.dropna(inplace=True)

# Effettuare il resample per mesi
dataset_raggruppato_mesi=dataset.resample("ME",on="data_osservazione")["temperatura_media","precipitazioni","umidita","velocita_vento"].mean().reset_index()
print(dataset_raggruppato_mesi)
dataset_raggruppato_anni=dataset.resample("YE",on="data_osservazione")["temperatura_media","precipitazioni","umidita","velocita_vento"].mean().reset_index()
print(dataset_raggruppato_anni)

# Applicare la normalizzazione Z-score alla temperatura_media, precipitazioni, umidità e velocità_vento per standardizzarle.
temperatura_media=dataset["temperatura_media"].mean()
temperatura_conteggio=dataset["temperatura_media"].count()

precipitazioni_media=dataset["precipitazioni"].mean()
precipitazioni_conteggio=dataset["precipitazioni"].count()

umidita_media=dataset["umidita"].mean()
umidita_conteggio=dataset["umidita"].count()

velocita_media=dataset["velocita_vento"].mean()
velocita_conteggio=dataset["velocita_vento"].count()

# La deviazione standard è la radice quadrata della divisione fra la media delle deviazioni e il numero della popolazione:
# Normalizzazione temperatura standard
dataset["temperatura_media_normalizzata"]=(dataset["temperatura_media"]-temperatura_media)/np.std(dataset["temperatura_media"])

# Normalizzazione colonna precipitazioni
dataset["precipitazioni_medie_normalizzate"]=(dataset["precipitazioni"]-precipitazioni_media)/np.std(dataset["precipitazioni"])

# Normalizzazione colonna umidità
dataset["umidita_media_normalizzate"]=(dataset["umidita"]-umidita_media)/np.std(dataset["umidita"])

# Normalizzazione colonna velocità
dataset["velocita_medie_normalizzate"]=(dataset["velocita_vento"]-velocita_media)/np.std(dataset["velocita_vento"])

# Calcolare statistiche descrittive (media, mediana, deviazione standard) per ogni variabile.
print("Media temperatura",dataset["temperatura_media"].mean())
print("Mediana temperatura",dataset["temperatura_media"].median())
print("Deviazione standard temperatura",np.std(dataset["temperatura_media"]),"\n")

print("Media precipitazioni",dataset["precipitazioni"].mean())
print("Mediana precipitazioni",dataset["precipitazioni"].median())
print("Deviazione precipitazioni",np.std(dataset["precipitazioni"]),"\n")

print("Media umidità",dataset["umidita"].mean())
print("Mediana umidità",dataset["umidita"].median())
print("Deviazione umidità",np.std(dataset["umidita"]),"\n")

print("Media velocità vento",dataset["velocita_vento"].mean())
print("Mediana velocità vento",dataset["velocita_vento"].median())
print("Deviazione velocità vento",np.std(dataset["velocita_vento"]),"\n")

# Creare grafici (istogrammi, boxplots) per visualizzare la distribuzione di ciascuna variabile normalizzata
#plt.hist(dataset.iloc[:,-4:])
#plt.show()
#
#plt.boxplot(dataset.iloc[:,-4:])
#plt.show()

#Utilizzare una heatmap per visualizzare la correlazione tra le diverse variabili meteorologiche.
dataset_raggruppato_mesi["data_osservazione"]=dataset_raggruppato_mesi["data_osservazione"].dt.date
temperatura_raggruppato_mesi=dataset_raggruppato_mesi.iloc[:,0:3].sort_values(by="data_osservazione").set_index("data_osservazione")
print(temperatura_raggruppato_mesi)
plt.figure(figsize=(10,6))
sns.heatmap(temperatura_raggruppato_mesi)
plt.show()

# Identificare eventuali correlazioni significative (es. tra temperatura e umidità).
dataset=dataset.iloc[:,0:5]
sns.heatmap(dataset[["temperatura_media","precipitazioni","umidita","velocita_vento"]].corr())
plt.show()
