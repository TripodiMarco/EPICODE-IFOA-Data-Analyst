import scrapy
import pandas as pd

class TestSiteSpider(scrapy.Spider):
    name = "test-site"
    # allowed_domains = ["www.webscraper.io"]
    start_urls = ["https://it.wikipedia.org/wiki/Psicologia_scolastica"]

    def parse(self, response):
        # CSS
        # tag_name -> cerca tutti i tag con quel nome
        # #id -> cerca tutti i tag in cui ci sia un attributo id proprio uguale a quello specificato dopo il cancelletto
        # <img id="test" src="..."> -> #test -> selettore che individua proprio questa immagine
        # .class_name -> cerca tutti i tag in cui ci sia un attributo class che contiene il nome della classe specificata
        # <img id="test" class="prima seconda terza" src="..."> -> .seconda selettore che individua questa immagine e tutte le altre che contengono la classe "seconda"
        # percorso interno -> cerca i tag <interno> a qualsiasi profondità all'interno del tag <percorso>
        # <percorso><div><div><interno></interno></div></div></percorso>
        # percorso > interno -> cerca i tag <interno> figli del tag <percorso>
        # <percorso><interno></interno></percorso>
        # links = response.css('a::attr(href)').getall()

        # XPATH
        # / -> separatore di percorso
        # html/head -> indica head figlio di html
        # // -> qualsiasi profondità
        # html//div -> indica div che è discendente di html a qualsiasi profondità
        # links = response.xpath("//a/@href").getall()
        llinks = response.xpath("//a[@href]")
        links = [h.extract() for h in llinks.xpath("@href")]
        df=pd.DataFrame([{"link": x} for x in links])
        for data in [{"link": x} for x in links]:
            yield data

