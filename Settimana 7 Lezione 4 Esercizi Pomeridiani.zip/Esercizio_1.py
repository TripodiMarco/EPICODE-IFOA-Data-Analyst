import scrapy

class NewsTitleSpider(scrapy.Spider):
    name="simple_text"
    start_urls=["https://example.com/news"]

    def parse(self,response):
        titles=response.css("h1::text").getall()
        for title in titles:
            yield {"title":title}
